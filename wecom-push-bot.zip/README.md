# WeCom Push Bot

将 image.jpg 上传到仓库根目录，并在 GitHub Secrets 中添加 WEBHOOK 即可每天自动推送图片。
